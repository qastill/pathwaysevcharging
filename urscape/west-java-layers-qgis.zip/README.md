# West Java layers for QGIS

GeoTIFF (EPSG:4326, 0.5 arc-minute cells, nodata -9999) of the 23 ur-scape layers + SPKLU points.
Drag the .tif files into QGIS; layer name, units, citation and category codes are in the file tags (Layer Properties > Metadata). To push any of them into ur-scape through its official QGIS plugin, use GIS/Plugins/ur-scapeDataImporter from the ur-scape download (resolution 'C', location 'West Java'); the ur-scape package in this repo already contains the same grids.

Source: Qashtalani Haramaini - pathwaysevcharging (PLN; TTM Alyas Widita; Kontur 2023; BPS; RUPTL 2025-2034 / OSM)
https://github.com/qastill/pathwaysevcharging
